# 3. Users and Groups

**Goal:** Create users and groups and control access with group ownership.

## Commands

```bash
whoami; id                          # current user, UID, groups
sudo adduser intern1                # create user (Debian/Ubuntu/Mint)
sudo passwd intern1                 # set password
sudo groupadd devteam               # create group
sudo usermod -aG devteam intern1    # add user to group (-a is essential)
groups intern1                      # show user's groups
cat /etc/passwd | grep intern1      # user database
cat /etc/group | grep devteam       # group database

# Shared directory exercise
mkdir ~/lab/shared
sudo chown :devteam ~/lab/shared
sudo chmod 770 ~/lab/shared
sudo -u intern1 touch ~/lab/shared/test.txt   # works (member)

su - intern1                        # switch user
sudo deluser intern1                # remove user (cleanup)
sudo delgroup devteam               # remove group (cleanup)
```

## My output

```
(paste your terminal output here)
```

## What I learned

- _Write 2-3 points in your own words._
