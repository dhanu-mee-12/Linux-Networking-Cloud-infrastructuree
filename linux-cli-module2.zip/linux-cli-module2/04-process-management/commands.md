# 4. Process Management

**Goal:** View, control and stop running processes.

## Commands

```bash
ps aux                       # all processes
ps aux | grep firefox        # find a process
top                          # live view (q to quit)
htop                         # nicer view: sudo apt install htop
sleep 300 &                  # run in background
jobs                         # list background jobs
fg %1 / bg %1                # bring to foreground / resume in background
kill <PID>                   # polite stop (SIGTERM)
kill -9 <PID>                # force kill (SIGKILL), last resort
pkill sleep                  # kill by name
nice -n 10 sleep 300 &       # start with lower priority
renice 5 -p <PID>            # change priority
nohup ./scripts/hello.sh &   # keep running after terminal closes
free -h; df -h; uptime       # memory, disk, load
```

## My output

```
(paste your terminal output here)
```

## What I learned

- _Write 2-3 points in your own words._
