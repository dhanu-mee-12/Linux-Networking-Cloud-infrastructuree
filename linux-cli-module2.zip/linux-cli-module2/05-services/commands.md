# 5. Services (systemd)

**Goal:** Manage background services and read their logs.

## Setup

```bash
sudo apt install nginx
```

## Commands

```bash
systemctl status nginx
sudo systemctl start nginx
sudo systemctl stop nginx
sudo systemctl restart nginx
sudo systemctl enable nginx       # start at boot
sudo systemctl disable nginx
systemctl is-enabled nginx
systemctl list-units --type=service --state=running
journalctl -u nginx               # logs for a service
journalctl -u nginx -f            # follow live
journalctl -xe                    # recent errors
```

## My output

```
(paste your terminal output here)
```

## What I learned

- _Write 2-3 points in your own words._
