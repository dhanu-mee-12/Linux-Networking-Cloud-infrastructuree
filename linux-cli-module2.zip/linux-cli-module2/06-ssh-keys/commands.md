# 6. SSH Keys

**Goal:** Set up key-based SSH login.

## Setup

```bash
sudo apt install openssh-server
sudo systemctl enable --now ssh
```

## Commands

```bash
ssh-keygen -t ed25519 -C "dhanu@laptop"   # creates ~/.ssh/id_ed25519 and .pub
ls -l ~/.ssh                               # private key must be 600
ssh-copy-id user@server_ip                 # install public key on server
ssh user@server_ip                         # log in with key
ssh -i ~/.ssh/mykey.pem ubuntu@ip          # specify a key (cloud VMs)
eval "$(ssh-agent -s)"; ssh-add ~/.ssh/id_ed25519   # load key into agent
scp file.txt user@ip:/home/user/           # copy over SSH
```

## Fixing permission errors

```bash
chmod 700 ~/.ssh
chmod 600 ~/.ssh/authorized_keys ~/.ssh/id_ed25519
```

## Security rules

- The **private key never leaves my machine** and is never committed to Git.
- Only the **public key** (`.pub`) is shared with servers.

## My output

```
(paste your terminal output here; do NOT include private keys)
```

## What I learned

- _Write 2-3 points in your own words._
