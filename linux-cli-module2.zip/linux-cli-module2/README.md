# Linux CLI: Module 2

Hands-on practice with the Linux command line, completed as part of my cloud computing internship.

- **Environment:** Linux Mint, Bash
- **Author:** Dhanusha | BSc Computer Science, Gandhigram Rural Institute

## Topics covered

| # | Topic | Folder |
|---|-------|--------|
| 1 | File operations | [01-file-operations](01-file-operations/commands.md) |
| 2 | File permissions | [02-permissions](02-permissions/commands.md) |
| 3 | Users and groups | [03-users-groups](03-users-groups/commands.md) |
| 4 | Process management | [04-process-management](04-process-management/commands.md) |
| 5 | Services (systemd) | [05-services](05-services/commands.md) |
| 6 | SSH keys | [06-ssh-keys](06-ssh-keys/commands.md) |

## How this repo is organised

Each folder contains a `commands.md` with the commands I ran, what they do, my output, and what I learned. Terminal screenshots go in each folder's `screenshots/` directory.

## Key learnings

- Permissions use r=4, w=2, x=1. Scripts and directories are usually 755, normal files 644, private keys 600.
- `usermod -aG` needs the `-a` flag, otherwise it replaces the user's existing groups.
- `kill` (SIGTERM) asks a process to stop politely; `kill -9` is a last resort.
- `systemctl start` runs a service now; `systemctl enable` makes it start at boot.
- The private SSH key never leaves my machine; only the public key goes to the server.

## Challenges and fixes

- _Add one real problem you hit and how you fixed it._

## How to reproduce

Run the commands in each `commands.md` on any Debian/Ubuntu-based system (some need `sudo`).

## Security note

No private keys or credentials are stored in this repository.
