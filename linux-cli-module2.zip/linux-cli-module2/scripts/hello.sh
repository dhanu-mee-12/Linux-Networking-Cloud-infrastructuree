#!/bin/bash
# Simple script used to practice execute permissions
echo "Hello from Linux CLI module 2"
echo "Running as user: $(whoami)"
echo "Date: $(date)"
